/* 
 * File:   Main.c
 * Author: ludo
 *
 * Created on 26 septembre 2018, 05:51
 */
#include <30F2010.h>
#include <stdio.h>
#include <stdlib.h>


#fuses FRC,NOWDT,NOPROTECT 
#use delay(clock=7.32Mhz)
const int bauds = 19200;
#use rs232 (baud=19200, parity=N,  xmit=PIN_C13,rcv=PIN_C14, bits = 8,ERRORS) //, RECEIVE_BUFFER=10) 
#USE TIMER(TIMER=1,BITS=16,ISR) // un ticks est de 1us 
#use delay(clock=8Mhz)

//d�claration des variables 
//unsigned int16 dutyD,dutyG; 
//float duty2D,duty2G; 
//float pas_dutyD,pas_dutyG; 
//long pr2 = 32768; 
long pr1 = 8500;
long pr2 = 10000;
unsigned int TabTensionMesure[5];
unsigned int TabTensionMesureMoy[5];
unsigned int TabTensionConsigne[5] = {1700, 1700, 1700, 1700, 4221}; // en mV  4221=10200mv/2.416
unsigned int TabTensionLim[5] = {1250, 1250, 1250, 1250, 3104}; // mv     3104=7500/2.416
unsigned int TensionA[5];
int deltaV = 50; //mv
//unsigned int TensionB[5,5];
unsigned int Etatcharge[5];
float PWM[5];
float PWMmax[5] = {100, 100, 100, 100, 100};

void Output(int i, int stat) {

    if (stat == 0) {
        switch (i) {
            case 0:
                output_low(PIN_E0);
                break;
            case 1:
                output_low(PIN_E1);
                break;
            case 2:
                output_low(PIN_E2);
                break;
            case 3:
                output_low(PIN_E3);
                break;
            case 4:
                //output_low(PIN_E4);
                break;
        }
    }
    if (stat == 1) {
        switch (i) {
            case 0:
                output_high(PIN_E0);
                break;
            case 1:
                output_high(PIN_E1);
                break;
            case 2:
                output_high(PIN_E2);
                break;
            case 3:
                output_high(PIN_E3);
                break;
            case 4:
                //output_high(PIN_E4);
                break;
        }
    }
}

void OutputLED(int i, int stat) {
    if (stat == 0) {
        switch (i) {
            case 0:
                output_low(PIN_E4);
                break;
            case 1:
                output_low(PIN_E5);
                break;
            case 2:
                output_low(PIN_E8);
                break;
            case 3:
                output_low(PIN_D0);
                break;
            case 4:
                output_low(PIN_D1);
                break;
        }
    }
    if (stat == 1) {
        switch (i) {
            case 0:
                output_high(PIN_E4);
                break;
            case 1:
                output_high(PIN_E5);
                break;
            case 2:
                output_high(PIN_E8);
                break;
            case 3:
                output_high(PIN_D0);
                break;
            case 4:
                output_high(PIN_D1);
                break;
        }

    }
    if (stat == 2) {
        switch (i) {
            case 0:
                output_toggle(PIN_E4);
                break;
            case 1:
                output_toggle(PIN_E5);
                break;
            case 2:
                output_toggle(PIN_E8);
                break;
            case 3:
                output_toggle(PIN_D0);
                break;
            case 4:
                output_toggle(PIN_D1);
                break;
        }

    }
}

unsigned int MesureBat(int i) {
    float tmp;
    unsigned long tmp2;
    set_adc_channel(i);
    delay_us(50);
    tmp2 = read_adc();
    tmp = (float) tmp2 * 0.0763; /// 65.536 * 5;
    //if (i == 4) {
    //    tmp=tmp*1.541;
    //}
    return (unsigned int) tmp; // en mv
}



#INT_TIMER1 

void isrT1(void) {
    int i;
    int tmp;
    //mesure des tensions
    for (i = 0; i < 4; i++) {
        TensionA[i] = MesureBat(i); // tension pile 1v5
        //printf(" %u", (TabTensionMesure[i])); //TensionA[i]);
    }
    //TensionA[4] = MesureBat(4); // tension pile 9v
    //tmp = (int) TensionA[4]*2.416;
    //printf(" \n"); //TensionA[i]);

    //ajustement des rapports cycliques
    for (i = 0; i < 4; i++) {
        if (TabTensionMesure[i] > TabTensionLim[i]) {
            //printf("%u %u,%u ", i, TabTensionMesure[i], TabTensionConsigne[i]);
            if (TabTensionMesure[i] > (TabTensionConsigne[i] + deltaV)) {
                PWM[i] = PWM[i] - 1;
            }
            if (TabTensionMesure[i] < (TabTensionConsigne[i] + deltaV)) {
                PWM[i] = PWM[i] + 1;
            }
            if (PWM[i] > PWMmax[i]) {
                PWM[i] = PWMmax[i];
            }
            if (PWM[i] < 0) {
                PWM[i] = 0;
                Etatcharge[i] = 0;
            }
            if (PWM[i] > 0) {
                if (Etatcharge[i] == 1) {
                    Output(i, 1);
                }
            }
        } else {
            PWM[i] = 0;
        }
    }
    //r�glage des �tat hauts
    float j = 0;
    char k = 0;
    char Out[5] = {0, 0, 0, 0, 0};
    while (k < 4) {
        k = 0;
        delay_us(1);
        j += 1.0;
        for (i = 0; i < 4; i++) {
            if ((j > PWM[i]) & (Out[i] == 0)) {
                Output(i, 0);
                Out[i] = 1;
                //TensionB[i] = MesureBat(i); //tension en charge
            }
        }
        //variable test de sortie si toutes les sorties � 0
        for (i = 0; i < 4; i++) {
            k += Out[i];
        }
    }
    for (i = 0; i < 4; i++) {
        //calcul tension moyenne
        TabTensionMesure[i] = (TensionA[i] + TabTensionMesure[i]) / 2;
        //printf("%u\n",TabTensionMesure[i]);
    }
    //TabTensionMesure[4] = TensionA[4];
    //tmp = (int) PWM[0]*10;
    // printf("%u %u\n", tmp, TensionA[0]);
}

void Initialisation() {
    //serial port 
    setup_uart(UART_DATA | TRUE); // accepte les donn�es | le met en marche 
    //   enable_interrupts(INT_RDA); 
    set_uart_speed(bauds);

    set_tris_b(0x3f);
    set_tris_d(0x3ff0);
    set_tris_e(0x0000);
    setup_adc_ports(sAN0 | sAN1 | sAN2 | sAN3 | sAN4, VSS_VDD);
    setup_adc(ADC_CLOCK | ADC_TAD_MUL_16);
    set_adc_channel(0); // chanel par defaut pour mesure vide 

    //timer 1 
    setup_timer1(TMR_INTERNAL | TMR_DIV_BY_8, pr1);
    setup_timer2(TMR_INTERNAL | TMR_DIV_BY_64, pr2);
    //interruptions 
    enable_interrupts(INT_TIMER1);
    enable_interrupts(INT_TIMER2);
    //ext_int_edge(INT_EXT0, L_TO_H);
    //enable_interrupts(INT_EXT0);
    // enable_interrupts(INT_TIMER3);   
    enable_interrupts(GLOBAL);
    printf("init termine\n");
    //printf("MES%u\n", Mesure++ Bat()); 
}


#INT_TIMER2 

void isrT2(void) {
    for (int i = 0; i < 4; i++) {
        printf(" %u", (TabTensionMesure[i]));
        if (TabTensionMesure[i] >= TabTensionConsigne[i] + deltaV) {
            OutputLED(i, 2);
            Etatcharge[i] = 0;
        }
        if (TabTensionMesure[i] < TabTensionConsigne[i] + deltaV) {
            OutputLED(i, 1);
            Etatcharge[i] = 1;
        }
        if (TabTensionMesure[i] <= TabTensionLim[i]) {
            OutputLED(i, 0);
            TabTensionMesure[i] = 0;
            Etatcharge[i] = 0;
        }
    }
    printf(" \n"); //TensionA[i]);
}

void main(void) {
    Initialisation();
    //output_high(PIN_B5);
    while (1) {
    }

}





